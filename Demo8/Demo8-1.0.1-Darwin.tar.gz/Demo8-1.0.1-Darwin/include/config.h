// the configured options and settings for Tutorial
#define Demo_VERSION_MAJOR 1
#define Demo_VERSION_MINOR 0

// does the platform provide pow function?
#define HAVE_POW
